//
//  ViewController.swift
//  rj284_p2
//
//  Created by Richard Jin on 10/2/21.
//

import UIKit

class PushViewController: UIViewController {

    private var nameTextField = UITextField()
    private var genreTextField = UITextField()
    private var ratingTextField = UITextField()
    private var yearTextField = UITextField()
    private var profileImageView = UIImageView()
    private var paimonImageView = UIImageView()
    weak var delegate: AddToWatchDelegate?
    private var index = IndexPath()
    private var saveButton = UIButton()
    private var alert = UIAlertController(title:"Error", message:"Please type something for both name and about!", preferredStyle: .alert)


//    weak var delegate: UpdateAboutDelegate?
    private var placeholderText: String?

    init(delegate: AddToWatchDelegate?) {
        self.nameTextField.placeholder = "Show Name"
        self.genreTextField.placeholder = "Show Genre"
        self.ratingTextField.placeholder = "Show Rating"
        self.yearTextField.placeholder = "Show Year"
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        navigationItem.title = "Edit Information"

        nameTextField.textColor = .systemBlue
        nameTextField.font = .systemFont(ofSize: 26, weight: .bold)
        nameTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameTextField)

        profileImageView.image = UIImage(named: "Aether")
        profileImageView.contentMode = .scaleAspectFill
        profileImageView.clipsToBounds = true
        profileImageView.layer.cornerRadius = 5
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(profileImageView)

        paimonImageView.image = UIImage(named: "Paimon")
        paimonImageView.contentMode = .scaleAspectFill
        paimonImageView.clipsToBounds = true
        paimonImageView.layer.cornerRadius = 5
        paimonImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(paimonImageView)

        saveButton.setTitle("Save", for: .normal)
        saveButton.setTitleColor(.systemBlue, for: .normal)
        saveButton.backgroundColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1)
        saveButton.layer.borderWidth = 1
        saveButton.layer.borderColor = UIColor.systemBlue.cgColor
        saveButton.layer.cornerRadius = 10
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        saveButton.addTarget(self, action: #selector(popViewController), for: .touchUpInside)
        view.addSubview(saveButton)

        ratingTextField.textColor = .black
        ratingTextField.font = .systemFont(ofSize: 20)
        ratingTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(ratingTextField)

        genreTextField.textColor = .black
        genreTextField.font = .systemFont(ofSize: 20)
        genreTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(genreTextField)
        
        yearTextField.textColor = .black
        yearTextField.font = .systemFont(ofSize: 20)
        yearTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(yearTextField)


        setupConstraints()


    }

    @objc func popViewController() {
        // TODO 9: call delegate function
//        if (self.nameTextField.text != "") && (self.genreTextField.text != "") && (self.ratingTextField.text != "") && (self.yearTextField.text != ""){
//            self.delegate?.updateAbout(watchStatus: self.watchStatus, genreString: self.genreTextField.text ?? "Genre", ratingString: self.ratingTextField.text ?? "Rating", yearString: self.yearTextField.text ?? "Year", didSelectItemAt: index)
        print("add show here")
        
        self.delegate?.addToWatch(nameString: self.nameTextField.text ?? "Unknown Name", genreString: self.genreTextField.text ?? "Unknown Genre", ratingString: self.ratingTextField.text ?? "Unknown Rating", yearString: self.yearTextField.text ?? "Unknown Year")
        self.navigationController?.popViewController(animated: true)
//        }
//        else{
//            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {action in
//                self.navigationController?.popViewController(animated: true)
//            }))
//        }

//        self.navigationController?.popViewController(animated: true)
//        self.present(alert, animated: true, completion: nil)

        // TODO 5: dismiss view controller

    }

    func setupConstraints() {
        NSLayoutConstraint.activate([
            profileImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            profileImageView.heightAnchor.constraint(equalToConstant: 260),
            profileImageView.widthAnchor.constraint(equalToConstant: 260),
            profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        NSLayoutConstraint.activate([
            nameTextField.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 20),
            nameTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        NSLayoutConstraint.activate([
            paimonImageView.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 8),
            paimonImageView.heightAnchor.constraint(equalToConstant: 100),
            paimonImageView.widthAnchor.constraint(equalToConstant: 100),
            paimonImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant:130)
        ])

        NSLayoutConstraint.activate([
            saveButton.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 50),
            saveButton.widthAnchor.constraint(equalToConstant: 100),
            saveButton.heightAnchor.constraint(equalToConstant: 50),
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        NSLayoutConstraint.activate([
            genreTextField.topAnchor.constraint(equalTo: saveButton.bottomAnchor, constant: 50),
            genreTextField.heightAnchor.constraint(equalToConstant: 17),
            genreTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        NSLayoutConstraint.activate([
            ratingTextField.topAnchor.constraint(equalTo: genreTextField.bottomAnchor, constant: 50),
            ratingTextField.heightAnchor.constraint(equalToConstant: 17),
            ratingTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        NSLayoutConstraint.activate([
            yearTextField.topAnchor.constraint(equalTo: ratingTextField.bottomAnchor, constant: 50),
            yearTextField.heightAnchor.constraint(equalToConstant: 17),
            yearTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])


    }

}

