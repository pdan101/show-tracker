//
//  ViewController.swift
//  sc2489_p5
//
//  Created by Siyuan Chen on 11/2/21.
//

import UIKit

protocol UpdateAboutDelegate: class {
    func updateAbout(watchStatus: Bool, genreString: String, ratingString: String, yearString: String, didSelectItemAt indexPath: IndexPath)
    func deleteSelf(watchStatus: Bool, name: String)
}

protocol AddToWatchDelegate: class {
    func addToWatch(nameString: String, genreString: String, ratingString: String, yearString: String)
    func addToWatchPlan(nameString: String, genreString: String, ratingString: String, yearString: String)
}


// TODO 6: create protocol to update title
class ViewController: UIViewController, UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        filterContentForSearchTextCurrent(searchBar.text!)
        filterContentForSearchTextPlan(searchBar.text!)
    }
    

    // set up view
    private var currentWatchView: UICollectionView!
    private var planView: UICollectionView!
    private var watchListLabel = UILabel()
    private var planToWatchLabel = UILabel()
    private var addButton = UIButton()
    
    private var filteredCurrent: [Show] = []
    private var filteredPlan: [Show] = []
    private var searchCurrentEmpty: Bool {
        return currentSearchController.searchBar.text?.isEmpty ?? true
    }
    private let currentSearchController = UISearchController(searchResultsController: nil)
    var isFiltering: Bool {
      return currentSearchController.isActive && !searchCurrentEmpty
    }
    private var login : Bool = false

    // Data
    private var currentWatch : [Show] = [Show(name: "The Walking Dead", genre: "Horror", year: 2010, rating: "4/5", watched: true),
                                         Show(name: "Game Of Thrones", genre: "Drama", year: 2011, rating: "4.5/5", watched: true),
                                         Show(name: "The Big Bang Theory", genre: "Comedy", year: 2007, rating: "4.5/5", watched: true),
                                         Show(name: "Squid Game", genre: "Thriller", year: 2021, rating: "4/5", watched: true),
                                         Show(name: "Family Guy", genre: "Comedy", year: 1999, rating: "3.5/5", watched: true),
                                         Show(name: "Friends", genre: "Sitcom", year: 1994, rating: "4.5/5", watched: true),
    ]
    
    private var planToWatch : [Show] = [Show(name: "South Park" ,genre: "Comedy", year: 1997, rating: "n/a", watched: false),
                                        Show(name: "The Office", genre: "Comedy", year: 2005, rating: "n/a", watched: false),
                                        Show(name: "Peaky Blinders", genre: "Action", year: 2013, rating: "n/a", watched: false),
                                        Show(name: "Narcos", genre: "Crime", year: 2018, rating: "n/a", watched: false),
                                        Show(name: "The Flash", genre: "Sci-Fi", year: 2014, rating: "n/a", watched: false),
//                                        Show(name: "Squid Game", genre: "Thriller", year: 2021, rating: "4/5", watched: false)
    ]
    
    private var selectedShows : [Show] = []
    
    private var loginTitle = UILabel()
    private var message1 = UILabel()
    private var message2 = UILabel()
    private var idTextField = UITextField()
    private var nameTextField = UITextField()
    private var launchButton = UIButton()

    // set up constants
    private let watchCellReuseIdentifier = "watchCellReuseIdentifier"
    private let planCellReuseIdentifier = "PlanCellReuseIdentifier"
    private let cellPadding: CGFloat = 10
    private let sectionPadding: CGFloat = 5

    override func viewDidLoad() {
        super.viewDidLoad()
        if (login == false){
            setUpLoginPage()
        }
        else {
            self.loginTitle.isHidden = true
            self.message1.isHidden = true
            self.message2.isHidden = true
            self.idTextField.isHidden = true
            self.nameTextField.isHidden = true
            self.launchButton.isHidden = true
            
            title = "Show Tracker"
            view.backgroundColor = .white

            // Setup flow layout
            let collectionLayout = UICollectionViewFlowLayout()
            collectionLayout.scrollDirection = .horizontal
            collectionLayout.minimumLineSpacing = cellPadding
            collectionLayout.minimumInteritemSpacing = cellPadding
            collectionLayout.sectionInset = UIEdgeInsets(top: sectionPadding, left: 0, bottom: sectionPadding, right: 0)
            
            let collectionLayout2 = UICollectionViewFlowLayout()
            collectionLayout2.scrollDirection = .horizontal
            collectionLayout2.minimumLineSpacing = cellPadding
            collectionLayout2.minimumInteritemSpacing = cellPadding
            collectionLayout2.sectionInset = UIEdgeInsets(top: sectionPadding, left: 0, bottom: sectionPadding, right: 0)

            // Instantiate collectionView and FilterView
            currentWatchView = UICollectionView(frame: .zero, collectionViewLayout: collectionLayout)
            currentWatchView.backgroundColor = .clear
            currentWatchView.translatesAutoresizingMaskIntoConstraints = false
            
            planView = UICollectionView(frame: .zero, collectionViewLayout: collectionLayout2)
            planView.backgroundColor = .clear
            planView.translatesAutoresizingMaskIntoConstraints = false

            // Create collection view cell and filter view cell and register it here.
            currentWatchView.register(ShowCollectionViewCell.self, forCellWithReuseIdentifier: watchCellReuseIdentifier)
            planView.register(ShowCollectionViewCell.self, forCellWithReuseIdentifier: planCellReuseIdentifier)

            // Set collection view and filter view data source
            currentWatchView.dataSource = self
            planView.dataSource = self

            // Set collection view and filter view delegate
            currentWatchView.delegate = self
            planView.delegate = self
            
            currentSearchController.searchResultsUpdater = self
            currentSearchController.obscuresBackgroundDuringPresentation = false
            currentSearchController.searchBar.placeholder = "Search Shows"
            navigationItem.searchController = currentSearchController
            definesPresentationContext = true
            
            watchListLabel.text = "Your Watch List"
            watchListLabel.textColor = .black
            watchListLabel.font = .systemFont(ofSize: 22, weight: .bold)
            watchListLabel.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(watchListLabel)
            
            planToWatchLabel.text = "Your Plan-To-Watch List"
            planToWatchLabel.textColor = .black
            planToWatchLabel.font = .systemFont(ofSize: 22, weight: .bold)
            planToWatchLabel.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(planToWatchLabel)
            
            addButton.translatesAutoresizingMaskIntoConstraints = false
            addButton.setTitle("Add", for: .normal)
            addButton.setTitleColor(.black, for: .normal)
            addButton.backgroundColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1)
            addButton.layer.cornerRadius = 4
            addButton.addTarget(self, action: #selector(pushViewControllerButtonPressed), for: .touchUpInside)
            view.addSubview(addButton)

            view.addSubview(currentWatchView)
            view.addSubview(planView)
            print(currentWatch)
            setupConstraints()
        }
    }

    func setupConstraints() {
        let filterViewPadding: CGFloat = 12
        NSLayoutConstraint.activate([
            watchListLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            watchListLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: filterViewPadding)
        ])
        NSLayoutConstraint.activate([
            currentWatchView.topAnchor.constraint(equalTo: watchListLabel.bottomAnchor, constant: filterViewPadding),
            currentWatchView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: filterViewPadding),
            currentWatchView.heightAnchor.constraint(equalToConstant: 180),
            currentWatchView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -filterViewPadding)
        ])
        NSLayoutConstraint.activate([
            planToWatchLabel.topAnchor.constraint(equalTo: currentWatchView.bottomAnchor, constant: 20),
            planToWatchLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: filterViewPadding)
        ])
        NSLayoutConstraint.activate([
            planView.topAnchor.constraint(equalTo: planToWatchLabel.bottomAnchor, constant: filterViewPadding),
            planView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: filterViewPadding),
            planView.heightAnchor.constraint(equalToConstant: 180),
            planView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -filterViewPadding)
        ])
        
        NSLayoutConstraint.activate([
            addButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            addButton.topAnchor.constraint(equalTo: planView.bottomAnchor, constant: filterViewPadding),
            addButton.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -24),
            addButton.heightAnchor.constraint(equalToConstant: 48)
        ])
    }
    
    func setUpLoginPage(){
        view.backgroundColor = .white

        loginTitle.text = "Welcome to Show Tracker"
        loginTitle.textColor = .black
        loginTitle.font = .systemFont(ofSize: 30, weight: .bold)
        loginTitle.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(loginTitle)
        
        message1.text = "If you have signed up, enter your ID:"
        message1.textColor = .darkGray
        message1.font = .systemFont(ofSize: 18, weight: .medium)
        message1.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(message1)
        
        message2.text = "If you haven't signed up, enter your name:"
        message2.textColor = .darkGray
        message2.font = .systemFont(ofSize: 18, weight: .medium)
        message2.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(message2)
        
        idTextField.textColor = .black
        idTextField.layer.borderWidth = 2
        idTextField.layer.borderColor = UIColor.systemGray.cgColor
        idTextField.font = .systemFont(ofSize: 20)
        idTextField.layer.cornerRadius = 15
        idTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(idTextField)
        
        nameTextField.textColor = .black
        nameTextField.layer.borderWidth = 2
        nameTextField.layer.borderColor = UIColor.systemGray.cgColor
        nameTextField.font = .systemFont(ofSize: 20)
        nameTextField.layer.cornerRadius = 15
        nameTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameTextField)
        
        launchButton.translatesAutoresizingMaskIntoConstraints = false
        launchButton.setTitle("Launch", for: .normal)
        launchButton.setTitleColor(.white, for: .normal)
        launchButton.backgroundColor = UIColor(red: 0/255, green: 255/255, blue: 80/255, alpha: 0.7)
        launchButton.layer.cornerRadius = 15
        launchButton.addTarget(self, action: #selector(launchButtonPressed), for: .touchUpInside)
        view.addSubview(launchButton)
        
        setUpLoginConstraints()
    }
    
    func setUpLoginConstraints() {
        let loginViewPadding: CGFloat = 15
        NSLayoutConstraint.activate([
            message1.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            message1.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: loginViewPadding),
            message1.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -loginViewPadding),
            message1.heightAnchor.constraint(equalToConstant: 40)
        ])
        NSLayoutConstraint.activate([
            loginTitle.bottomAnchor.constraint(equalTo: message1.topAnchor, constant: -loginViewPadding),
            loginTitle.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loginTitle.heightAnchor.constraint(equalToConstant: 150)
        ])
        NSLayoutConstraint.activate([
            idTextField.topAnchor.constraint(equalTo: message1.bottomAnchor, constant: loginViewPadding),
            idTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: loginViewPadding),
            idTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -loginViewPadding),
            idTextField.heightAnchor.constraint(equalToConstant: 40)
        ])
        NSLayoutConstraint.activate([
            message2.topAnchor.constraint(equalTo: idTextField.bottomAnchor, constant: loginViewPadding),
            message2.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: loginViewPadding),
            message2.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -loginViewPadding),
            message2.heightAnchor.constraint(equalToConstant: 40)
        ])
        NSLayoutConstraint.activate([
            nameTextField.topAnchor.constraint(equalTo: message2.bottomAnchor, constant: loginViewPadding),
            nameTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: loginViewPadding),
            nameTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -loginViewPadding),
            nameTextField.heightAnchor.constraint(equalToConstant: 40)
        ])
        NSLayoutConstraint.activate([
            launchButton.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: loginViewPadding),
            launchButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            launchButton.heightAnchor.constraint(equalToConstant: 50),
            launchButton.widthAnchor.constraint(equalToConstant: 100)
        ])
    }
    
    
    @objc func pushViewControllerButtonPressed() {
        // TODO 3: create VC to push
        let vc = PushViewController(delegate: self)
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func launchButtonPressed() {
        // TODO 3: create VC to push
        login = true
        self.viewDidLoad()
    }

}

// TODO 4: Conform to UICollectionViewDataSource
extension ViewController: UICollectionViewDataSource {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == currentWatchView{
                if isFiltering == true {
                    return filteredCurrent.count
                } else {
                print(currentWatch.count)
                return currentWatch.count
                }
        }
        else {
                if isFiltering == true {
                    return filteredPlan.count
                } else {
                print(planToWatch.count)
                return planToWatch.count
                }
        }
    }
    

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == planView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: planCellReuseIdentifier, for: indexPath) as! ShowCollectionViewCell
            if selectedShows.isEmpty{
                if isFiltering == true {
                    let show = filteredPlan[indexPath.item]
                    cell.configure(for: show)
                } else {
                let show = planToWatch[indexPath.item]
                cell.configure(for: show)
                }
            }
            else{
                let show = selectedShows[indexPath.item]
                cell.configure(for: show)
            }
            return cell
        }
        
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: watchCellReuseIdentifier, for: indexPath) as! ShowCollectionViewCell
            if selectedShows.isEmpty{
                if isFiltering == true {
                    let show = filteredCurrent[indexPath.item]
                    cell.configure(for: show)
                } else {
                let show = currentWatch[indexPath.item]
                cell.configure(for: show)
                }
            }
            else{
                let show = selectedShows[indexPath.item]
                cell.configure(for: show)
            }
            return cell
        }
    }
    
}

// TODO 5: Confrom to UICollectionViewDelegateFlowLayout
// TODO 7: Conform to UICollectionViewDelegate, implement interaction
extension ViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == planView{
            let numItemsPerRow: CGFloat = 2.0
            let size = (collectionView.frame.width - cellPadding) / numItemsPerRow
            return CGSize(width: size, height: size)
        }
        else{
            let numItemsPerRow: CGFloat = 2.0
            let size = (collectionView.frame.width - cellPadding) / numItemsPerRow
            return CGSize(width: size, height: size)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        var show : Show
        if (collectionView == planView){
            if isFiltering == true {
                show = filteredPlan[indexPath.item]
            } else {
            show = planToWatch[indexPath.item]
            }
        }
        else{
            if isFiltering == true {
                show = filteredCurrent[indexPath.item]
            } else {
            show = currentWatch[indexPath.item]
            }
        }
        let vc = ShowPushViewController(delegate: self, indexPath: indexPath, name: show.getName(), watched: show.getWatchStatus(), oldGenre: show.getGenre(), oldRating: show.getRating(), oldYear: show.getYear())
        navigationController?.pushViewController(vc, animated: true)
    }
}


extension ViewController: UpdateAboutDelegate {
    func deleteSelf(watchStatus: Bool, name: String) {
        if watchStatus {
            for show in currentWatch{
                if (show.name == name){
                    if let index = currentWatch.firstIndex(where: {$0.name == show.name}){
                        currentWatch.remove(at: index)
                    }
                }
            }
            currentWatchView.reloadData()
        }
        else{
            for show in planToWatch{
                if (show.name == name){
                    if let index = planToWatch.firstIndex(where: {$0.name == show.name}){
                        planToWatch.remove(at: index)
                    }
                }
            }
            planView.reloadData()
        }
    }
    

    func updateAbout(watchStatus: Bool, genreString: String, ratingString: String, yearString: String, didSelectItemAt indexPath: IndexPath) {
        
        if watchStatus {
            if let cell = currentWatchView.cellForItem(at: indexPath) as? ShowCollectionViewCell {
                cell.updateData(genre: genreString, rating: ratingString, year: yearString)
            }
        }
        else{
            if let cell = planView.cellForItem(at: indexPath) as? ShowCollectionViewCell {
                cell.updateData(genre: genreString, rating: ratingString, year: yearString)
            }
        }
    }
}

extension ViewController: AddToWatchDelegate {

    func addToWatch(nameString: String, genreString: String, ratingString: String, yearString: String) {
        var isAlreadyIn = 0
        for show in currentWatch{
            if (show.name == nameString){
                isAlreadyIn = 1
                show.genre = genreString
                show.rating = ratingString
                show.year = Int(yearString) ?? 0
            }
        }
        if (isAlreadyIn == 0){
            let newShow = Show(name: nameString, genre: genreString, year: 0, rating: ratingString, watched: true)
            currentWatch.append(newShow)
        }
        currentWatchView.reloadData()
    }
    
    func addToWatchPlan(nameString: String, genreString: String, ratingString: String, yearString: String) {
        
        let newShow = Show(name: nameString, genre: genreString, year: 0, rating: ratingString, watched: false)
        planToWatch.append(newShow)
        planView.reloadData()
    }
    
    func filterContentForSearchTextCurrent(_ searchText: String) {
        filteredCurrent = currentWatch.filter { (show: Show) -> Bool in
        return show.name.lowercased().contains(searchText.lowercased())
      }
      
      currentWatchView.reloadData()
    }
    
    func filterContentForSearchTextPlan(_ searchText: String) {
        filteredPlan = planToWatch.filter { (show: Show) -> Bool in
        return show.name.lowercased().contains(searchText.lowercased())
      }
      
      planView.reloadData()
    }
}
