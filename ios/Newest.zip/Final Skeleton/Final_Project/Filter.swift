//
//  Filter.swift
//  sc2489_p5
//
//  Created by Siyuan Chen on 11/2/21.
//

import Foundation
import UIKit

class Filter{
    var label: String
    var isClicked: Bool
    
    init(name: String){
        self.label = name
        self.isClicked = false
    }
}
