//
//  ViewController.swift
//  rj284_p2
//
//  Created by Richard Jin on 10/2/21.
//

import UIKit

class PushViewController: UIViewController {

    private var nameTextField = UITextField()
    private var genreTextField = UITextField()
    private var ratingTextField = UITextField()
    private var yearTextField = UITextField()
    private var profileImageView = UIImageView()
    private var paimonImageView = UIImageView()
    weak var delegate: AddToWatchDelegate?
    private var index = IndexPath()
    private var saveButton = UIButton()
    private var savePlanButton = UIButton()
    private var alert = UIAlertController(title:"Error", message:"Please fill out every text field!", preferredStyle: .alert)


    private var placeholderText: String?

    init(delegate: AddToWatchDelegate?) {
        self.nameTextField.placeholder = "Show Name"
        self.genreTextField.placeholder = "Show Genre"
        self.ratingTextField.placeholder = "Show Rating"
        self.yearTextField.placeholder = "Show Year"
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        navigationItem.title = "Edit Information"

        nameTextField.textColor = .systemBlue
        nameTextField.font = .systemFont(ofSize: 26, weight: .bold)
        nameTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameTextField)

        saveButton.setTitle("Save to watch list", for: .normal)
        saveButton.setTitleColor(.systemBlue, for: .normal)
        saveButton.backgroundColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1)
        saveButton.layer.borderWidth = 1
        saveButton.layer.borderColor = UIColor.systemBlue.cgColor
        saveButton.layer.cornerRadius = 10
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        saveButton.addTarget(self, action: #selector(popViewController), for: .touchUpInside)
        view.addSubview(saveButton)
        
        savePlanButton.setTitle("Save to plan-to-watch list", for: .normal)
        savePlanButton.setTitleColor(.systemBlue, for: .normal)
        savePlanButton.backgroundColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1)
        savePlanButton.layer.borderWidth = 1
        savePlanButton.layer.borderColor = UIColor.systemBlue.cgColor
        savePlanButton.layer.cornerRadius = 10
        savePlanButton.translatesAutoresizingMaskIntoConstraints = false
        savePlanButton.addTarget(self, action: #selector(popViewControllerForPlan), for: .touchUpInside)
        view.addSubview(savePlanButton)

        ratingTextField.textColor = .black
        ratingTextField.font = .systemFont(ofSize: 20)
        ratingTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(ratingTextField)

        genreTextField.textColor = .black
        genreTextField.font = .systemFont(ofSize: 20)
        genreTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(genreTextField)
        
        yearTextField.textColor = .black
        yearTextField.font = .systemFont(ofSize: 20)
        yearTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(yearTextField)


        setupConstraints()


    }

    @objc func popViewController() {
        
        self.delegate?.addToWatch(nameString: self.nameTextField.text ?? "Unknown Name", genreString: self.genreTextField.text ?? "Unknown Genre", ratingString: self.ratingTextField.text ?? "Unknown Rating", yearString: self.yearTextField.text ?? "Unknown Year")
        self.navigationController?.popViewController(animated: true)


    }
    
    @objc func popViewControllerForPlan() {
        
        self.delegate?.addToWatchPlan(nameString: self.nameTextField.text ?? "Unknown Name", genreString: self.genreTextField.text ?? "Unknown Genre", ratingString: self.ratingTextField.text ?? "Unknown Rating", yearString: self.yearTextField.text ?? "Unknown Year")
        self.navigationController?.popViewController(animated: true)

    }

    func setupConstraints() {

        NSLayoutConstraint.activate([
            nameTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            nameTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        NSLayoutConstraint.activate([
            genreTextField.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 50),
            genreTextField.heightAnchor.constraint(equalToConstant: 17),
            genreTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        NSLayoutConstraint.activate([
            ratingTextField.topAnchor.constraint(equalTo: genreTextField.bottomAnchor, constant: 50),
            ratingTextField.heightAnchor.constraint(equalToConstant: 17),
            ratingTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        NSLayoutConstraint.activate([
            yearTextField.topAnchor.constraint(equalTo: ratingTextField.bottomAnchor, constant: 50),
            yearTextField.heightAnchor.constraint(equalToConstant: 17),
            yearTextField.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        NSLayoutConstraint.activate([
            saveButton.topAnchor.constraint(equalTo: yearTextField.bottomAnchor, constant: 50),
            saveButton.widthAnchor.constraint(equalToConstant: 300),
            saveButton.heightAnchor.constraint(equalToConstant: 50),
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        NSLayoutConstraint.activate([
            savePlanButton.topAnchor.constraint(equalTo: saveButton.bottomAnchor, constant: 10),
            savePlanButton.widthAnchor.constraint(equalToConstant: 300),
            savePlanButton.heightAnchor.constraint(equalToConstant: 50),
            savePlanButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])


    }

}

